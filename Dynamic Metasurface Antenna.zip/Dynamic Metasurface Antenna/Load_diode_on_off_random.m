number_of_model = 1;
number_of_mask = 12;
name_folder = 'I:\CST Matlab API\CST-MATLAB-API-master\DOA';
for g= 1:number_of_model
    for k = 1:number_of_mask
    name =[name_folder,'\diode_on_off_save_random_',num2str(g),num2str(k),'.mat'];
    load(name,'diode_on_off_save');
    end

end