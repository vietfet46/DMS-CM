clc;
name_folder = '...';% Path to folder named 'CST Matlab API'
addpath(name_folder,'\CST-MATLAB-API-master');
addpath(name_folder,'\CST-MATLAB-API-master\Home');
addpath(name_folder,'\CST-MATLAB-API-master\Materials');
addpath(name_folder,'\CST-MATLAB-API-master\Modeling');
addpath(name_folder,'\CST-MATLAB-API-master\PostProcessing');
addpath(name_folder,'\CST-MATLAB-API-master\Simulation');

number_of_model = 1;
nPix = 20;
%for g= 1:number_of_model
%    for i= 1:nPix
%       for j= 1:nPix
%        pixels_save{g}(i,j)=0;
%        end
%   end
%end

%% Set Imaging Parameters
f0 = 21e09; %Imaging Frequency
c=3e08; %Speed of Light
lambda0 = c/f0; %Calculating the Wavelength
epsilon_r = 3.55; %Dielectric constant
lambda_g = lambda0/sqrt((epsilon_r+1)/2);
k0 = 2*pi/lambda0; % Calculating the Wavenumber (Single Frequency)
mm = 1000;

name_folder = '\Dynamic Metasurface Antenna';% Path to folder named 'Dynamic Metasurface Antenna'
for g= 1:number_of_model
%name =[name_folder,'\pixels_save_',num2str(g),'.mat'];      
name =[name_folder,'\pixels_save_',num2str(g),'.mat'];
load(name,'pixels_save');
pixels=pixels_save{g}; 

%pixels_save{g}= logical(randi(2,nPix)-1);
%pixels=logical(randi(2,nPix)-1);
%pixels_save{g}=pixels;

%name =['I:\CST Matlab API\CST-MATLAB-API-master\DMA_BigArray_with_NFS_withTarget_wo_Target_3\pixels_save_',num2str(g),'.mat'];
%save(name,'pixels_save');
%pixels =(randi(2,nPix)-1);
%pixels_1=pixels;

%Here, the total subtrate size

substrateSize = 80;
unitCellSize = substrateSize./nPix; 
subHeight = 1.52;

%define R,L,C of diode
Ls=0.1e-09;
Rf=5;
Cf=0;
Rrv=10e+03;
Crv=0.025e-12;

%define frequency and wavelength

lambda0 = 15;

%define length of lumped elements or lumped port
xlumped=0.5;

%define parameters of unitcell

a = 2.8;
b = 1.2;

[x,y] = meshgrid(0:substrateSize/nPix:substrateSize,0:substrateSize/nPix:substrateSize);

number_of_mask = 24;


for k = 1:number_of_mask

%%%%%%%%%%%%%%%%%%%%%%%% Create aperture with NFS%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cst = actxserver('CSTStudio.application');

%This command is used to open a new CST project. From now on this mws
%variable will be used to operate any matlab function that is used for the
%control of CST
mws = cst.invoke('NewMWS');


%Sets default units for your project. mm, GHz e.t.c you can open
%CSTDefaultUnits to see the exact selections or if you want I have
%CSTDefineUnits function in the api Home folder that you can use to assign you own units
CstDefaultUnits(mws) 

%The frequency sweep of your simulation. Here in GHz, remember that the
%CSTDefaulttUnits from before uses GHz
CstDefineFrequencyRange(mws,20,22)

%Initiates the auto-meshing
CstMeshInitiator(mws)

%This one defines your boundaries, here we are using expanded open since
%our structure is not some kind of waveguide or unit cell

%Remember that you must define your boundary according to your 
%lowest frequency of simulation (minfrequency), here it's 1.5GHz 
Xmin='open';   %'expanded open';
Xmax='open';
Ymin='open';
Ymax='open';
Zmin='expanded open';
Zmax='expanded open';
minfrequency = 20;
CstDefineOpenBoundary(mws,minfrequency,Xmin,Xmax,Ymin,Ymax,Zmin,Zmax)

%This function defines the Backround material, here we are using the
%default assignment of CST which is vacuum (permittivity=permeability=1)
%Once again, XminSpace, Xmaxspace e.t.c are the default assignments of CST
%for antennas
XminSpace = 0;
XmaxSpace = 0;
YminSpace = 0;
YmaxSpace = 0;
ZminSpace = 0;
ZmaxSpace = 0;
CstDefineBackroundMaterial(mws,XminSpace,XmaxSpace, YminSpace, YmaxSpace, ZminSpace, ZmaxSpace)

%These two functions are material properties functions. Here there is a
%little trick: You can't call and assign a material from the CST library using matlab or any kind of code (besides PEC). 
%It is a bit more complicated, you need to see the properties of the
%desired material in CST library and make a matlab function with all these properties, name the material and call it in your code by that name.
%This is a painfull process but I've managed to replicate some of the most
%important. You can find them in the materials folder of the API, once you
%get a grip of how my code works feel free to add more materials to that
%folder

%Here I am calling Copper annealed lossy and FR4 lossy, after these two
%function I can just write their names as a string and assign them to any
%desired shape
CstCopperAnnealedLossy(mws)
CstFR4lossy(mws)
CstRogerRO403C(mws)
CstTeflonPTFElossy(mws)
CstAir(mws)
    


%%%%%%%%%%%%%%%%%%%%%%%%%%% Create aperture 2 %%%%%%%%%%%%%%%%%%%%

%x_sw_aperture_1 = substrateSize+10;
x_sw_aperture_1 = 0;
%y_sw_aperture_1 = -substrateSize-10;
y_sw_aperture_1 = 0;

%% Define subtrate
%This creates the substrate
Name = 'Substrate_1';
component = 'component1';
material = 'RogerRO403C (lossy)';
Xrange = [0 substrateSize];
Yrange = [0 substrateSize];
Zrange = [0 subHeight];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange);
Name_Sub='component1:Substrate_1';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1 ,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

%% Define SMA connector 1
ra_in_SMA = 0.2/2; % 1.27/2; %
ra_pin = 0.2/2;%1.27/2; %
ra_pin_add = 0.04;%1.2;
ra_out_SMA = 0.69/2;%4.38/2; %
th_copper=0.035;
%th_copper=0;
ra_out_SMA_add_copper=ra_out_SMA +th_copper;
segments = 0;
length_in = subHeight;
length_pin_out = 1;
x_sw_SMA = substrateSize/2;
y_sw_SMA = substrateSize/2;
n_pix_SMA = 5;
sw_x_SMA_1 = 0;
sw_y_SMA_1 = unitCellSize*n_pix_SMA;

material1 = 'Copper (annealed)';
ComponentList = 'component1';
name1 = ['Outer_cylinder_SMA_1',num2str(1)];
OuterRadius = ra_out_SMA_add_copper;
InnerRadius = ra_out_SMA ;
Xcenter = x_sw_SMA+sw_x_SMA_1;
Ycenter = y_sw_SMA+sw_y_SMA_1;
Zrange = [0 -length_pin_out];
Cstcylinder(mws, name1, ComponentList, material1, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange)
Name_Sub='component1:Outer_cylinder_SMA_11';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

material2 = 'Teflon (PTFE) (lossy)';
ComponentList = 'component1';
name2 = ['Inner_coil_SMA_1',num2str(1)];
OuterRadius = ra_out_SMA;
InnerRadius = ra_in_SMA;
Xcenter = x_sw_SMA+sw_x_SMA_1;
Ycenter = y_sw_SMA+sw_y_SMA_1;
Zrange = [0 -length_pin_out];
Cstcylinder(mws, name2, ComponentList, material2, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange)
Name_Sub='component1:Inner_coil_SMA_11';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

material3 = 'Copper (annealed)';
ComponentList = 'component1';
name3 = ['Inner_cylinder_SMA_1',num2str(1)];
OuterRadius = ra_in_SMA;
InnerRadius = 0;
Xcenter = x_sw_SMA+sw_x_SMA_1;
Ycenter = y_sw_SMA+sw_y_SMA_1;
Zrange = [0 -length_pin_out];
Cstcylinder(mws, name3, ComponentList, material3, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange)
Name_Sub='component1:Inner_cylinder_SMA_11';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);


material4 = 'Copper (annealed)';
ComponentList = 'component1';
name4 = ['Inner_pin_SMA_1',num2str(1)];
OuterRadius = ra_in_SMA;
InnerRadius = 0;
Xcenter = x_sw_SMA+sw_x_SMA_1;
Ycenter = y_sw_SMA+sw_y_SMA_1;
Zrange = [0 length_in];
Cstcylinder(mws, name4, ComponentList, material4, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange)
Name_Sub='component1:Inner_pin_SMA_11';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

%% Define SMA connector 2
sw_x_SMA_2 = -unitCellSize*n_pix_SMA;
sw_y_SMA_2 = -unitCellSize*n_pix_SMA;

material1 = 'Copper (annealed)';
ComponentList = 'component1';
name1 = ['Outer_cylinder_SMA_1',num2str(2)];
OuterRadius = ra_out_SMA_add_copper;
InnerRadius = ra_out_SMA ;
Xcenter = x_sw_SMA+sw_x_SMA_2;
Ycenter = y_sw_SMA+sw_y_SMA_2;
Zrange = [0 -length_pin_out];
Cstcylinder(mws, name1, ComponentList, material1, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange)
Name_Sub='component1:Outer_cylinder_SMA_12';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

material2 = 'Teflon (PTFE) (lossy)';
ComponentList = 'component1';
name2 = ['Inner_coil_SMA_1',num2str(2)];
OuterRadius = ra_out_SMA;
InnerRadius = ra_in_SMA;
Xcenter = x_sw_SMA+sw_x_SMA_2;
Ycenter = y_sw_SMA+sw_y_SMA_2;
Zrange = [0 -length_pin_out];
Cstcylinder(mws, name2, ComponentList, material2, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange)
Name_Sub='component1:Inner_coil_SMA_12';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

material3 = 'Copper (annealed)';
ComponentList = 'component1';
name3 = ['Inner_cylinder_SMA_1',num2str(2)];
OuterRadius = ra_in_SMA;
InnerRadius = 0;
Xcenter = x_sw_SMA+sw_x_SMA_2;
Ycenter = y_sw_SMA+sw_y_SMA_2;
Zrange = [0 -length_pin_out];
Cstcylinder(mws, name3, ComponentList, material3, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange)
Name_Sub='component1:Inner_cylinder_SMA_12';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);


material4 = 'Copper (annealed)';
ComponentList = 'component1';
name4 = ['Inner_pin_SMA_1',num2str(2)];
OuterRadius = ra_in_SMA;
InnerRadius = 0;
Xcenter = x_sw_SMA+sw_x_SMA_2;
Ycenter = y_sw_SMA+sw_y_SMA_2;
Zrange = [0 length_in];
Cstcylinder(mws, name4, ComponentList, material4, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange)
Name_Sub='component1:Inner_pin_SMA_12';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

%% Define GND
Name = 'Groundplane_1';
component = 'component1';
material = 'Copper (annealed)';
Xrange = [0 substrateSize];
Yrange = [0 substrateSize];
Zrange = [0 -th_copper];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)
Name_Sub='component1:Groundplane_1';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1 ,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);


material5 = 'Copper (annealed)';
ComponentList = 'component1';
name5 = ['Outer_cylinder_1',num2str(1)];
OuterRadius = ra_out_SMA;
InnerRadius = 0;
Xcenter = x_sw_SMA+sw_x_SMA_1;
Ycenter = y_sw_SMA+sw_y_SMA_1;
Zrange = [0 -th_copper];
Cstcylinder(mws, name5, ComponentList, material5, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange);
Name_Sub='component1:Outer_cylinder_11';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

%This subtracts two components
component1 = 'component1:Groundplane_1';
component2 = 'component1:Outer_cylinder_11';
CstSubtract(mws,component1,component2)

material5 = 'Copper (annealed)';
ComponentList = 'component1';
name5 = ['Outer_cylinder_1',num2str(2)];
OuterRadius = ra_out_SMA;
InnerRadius = 0;
Xcenter = x_sw_SMA+sw_x_SMA_2;
Ycenter = y_sw_SMA+sw_y_SMA_2;
Zrange = [0 -th_copper];
Cstcylinder(mws, name5, ComponentList, material5, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange);
Name_Sub='component1:Outer_cylinder_12';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

%This subtracts two components
component1 = 'component1:Groundplane_1';
component2 = 'component1:Outer_cylinder_12';
CstSubtract(mws,component1,component2)


%Name_Sub='component1:Groundplane_2';
%center = [substrateSize/2 substrateSize/2 0];
%move = [-substrateSize/2+x_sw_aperture_2,-substrateSize/2+y_sw_aperture_2,0];
%CstTranslate(mws,Name_Sub,center,move,'False',1);

%% Define Patch
%This one creates the patch
Name = 'Patch_1';
component = 'component1';
material = 'Copper (annealed)';
Xrange = [0 substrateSize];
Yrange = [0 substrateSize];
Zrange = [subHeight subHeight+th_copper];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)

material6 = 'Copper (annealed)';
ComponentList = 'component1';
name6 = ['Inner_cylinder_3',num2str(1)];
OuterRadius = ra_pin+ra_pin_add;
InnerRadius = ra_pin;
Xcenter = x_sw_SMA+sw_x_SMA_1;
Ycenter = y_sw_SMA+sw_y_SMA_1;
Zrange = [subHeight subHeight+th_copper];
Cstcylinder(mws, name6, ComponentList, material6, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange);

%This subtracts two components
component1 = 'component1:Patch_1';
component2 = 'component1:Inner_cylinder_31';
CstSubtract(mws,component1,component2)

material6 = 'Copper (annealed)';
ComponentList = 'component1';
name6 = ['Inner_cylinder_3',num2str(2)];
OuterRadius = ra_pin+ra_pin_add;
InnerRadius = ra_pin;
Xcenter = x_sw_SMA+sw_x_SMA_2;
Ycenter = y_sw_SMA+sw_y_SMA_2;
Zrange = [subHeight subHeight+th_copper];
Cstcylinder(mws, name6, ComponentList, material6, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange);

%This subtracts two components
component1 = 'component1:Patch_1';
component2 = 'component1:Inner_cylinder_32';
CstSubtract(mws,component1,component2)

%% Define without Target
%This one creates the patch
Name = 'NFS';
component = 'component1';
material = 'Air';
dNFS = 5*15;
%dNFS =3;
NFS_Size = 175;
%NFS_Size_Y = 265;
Xrange = [0 NFS_Size];
Yrange = [0 NFS_Size];
Zrange = [subHeight+th_copper+dNFS subHeight+th_copper+dNFS];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange);

Name_Sub='component1:NFS';
center = [NFS_Size/2 NFS_Size/2 0];
move = [-NFS_Size/2+x_sw_aperture_1,-NFS_Size/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

%% Define waveport 3
%name = ['Port',num2str(1)];
%CST.addWaveguidePort('zmax',[0.62  1.38 ],[4.62  5.38],-length_pin_out);
Name = 'Outer_cylinder_SMA_11';
id = 1;
CstPickFace(mws,Name,id)
%Here I am assigning a waveguide port (I think I have most of the possible CST ports as functions in my api)
PortNumber = 1;
name = 1;
Xrange = [0.62 1.38];
Yrange = [9.62 10.38];
Zrange = [-length_pin_out -length_pin_out];
XrangeAdd =[0 0];
YrangeAdd =[0 0];
ZrangeAdd =[0 0];
Coordinates = 'Picks';
Orientation = 'positive';
CstWaveguidePort(mws,PortNumber, Xrange, Yrange, Zrange, XrangeAdd, YrangeAdd, ZrangeAdd,Coordinates,Orientation)

%% Define waveport 4
%name = ['Port',num2str(1)];
%CST.addWaveguidePort('zmax',[0.62  1.38 ],[4.62  5.38],-length_pin_out);
Name = 'Outer_cylinder_SMA_12';
id = 1;
CstPickFace(mws,Name,id)
%Here I am assigning a waveguide port (I think I have most of the possible CST ports as functions in my api)
PortNumber = 2;
name = 2;
Xrange = [0.62 1.38];
Yrange = [9.62 10.38];
Zrange = [-length_pin_out -length_pin_out];
XrangeAdd =[0 0];
YrangeAdd =[0 0];
ZrangeAdd =[0 0];
Coordinates = 'Picks';
Orientation = 'positive';
CstWaveguidePort(mws,PortNumber, Xrange, Yrange, Zrange, XrangeAdd, YrangeAdd, ZrangeAdd,Coordinates,Orientation)

%% Define array of unitcells
ii = 0;
for i = 2:nPix-1
    for j = 2:nPix-1
        e11= isequal([i j],[10+2 n_pix_SMA+2+10]);
        e21= isequal([i j],[10+2 n_pix_SMA+1+10]);
        e31= isequal([i j],[10+2 n_pix_SMA+10]);
        e41= isequal([i j],[10+2 n_pix_SMA-1+10]);
        e51= isequal([i j],[10+1 n_pix_SMA+2+10]);
        e61= isequal([i j],[10+1 n_pix_SMA+1+10]);
        e71= isequal([i j],[10+1 n_pix_SMA+10]);
        e81= isequal([i j],[10+1 n_pix_SMA-1+10]);
        e91= isequal([i j],[10 n_pix_SMA+2+10]);
        e101= isequal([i j],[10 n_pix_SMA+1+10]);
        e111= isequal([i j],[10 n_pix_SMA+10]);
        e121= isequal([i j],[10 n_pix_SMA-1+10]);
        e131= isequal([i j],[10-1 n_pix_SMA+2+10]);
        e141= isequal([i j],[10-1 n_pix_SMA+1+10]);
        e151= isequal([i j],[10-1 n_pix_SMA+10]);
        e161= isequal([i j],[10-1 n_pix_SMA-1+10]);
        
        e12= isequal([i j],[-n_pix_SMA+10+2 -n_pix_SMA+2+10]);
        e22= isequal([i j],[-n_pix_SMA+10+2 -n_pix_SMA+1+10]);
        e32= isequal([i j],[-n_pix_SMA+10+2 -n_pix_SMA+10]);
        e42= isequal([i j],[-n_pix_SMA+10+2 -n_pix_SMA-1+10]);
        e52= isequal([i j],[-n_pix_SMA+10+1 -n_pix_SMA+2+10]);
        e62= isequal([i j],[-n_pix_SMA+10+1 -n_pix_SMA+1+10]);
        e72= isequal([i j],[-n_pix_SMA+10+1 -n_pix_SMA+10]);
        e82= isequal([i j],[-n_pix_SMA+10+1 -n_pix_SMA-1+10]);
        e92= isequal([i j],[-n_pix_SMA+10 -n_pix_SMA+2+10]);
        e102= isequal([i j],[-n_pix_SMA+10 -n_pix_SMA+1+10]);
        e112= isequal([i j],[-n_pix_SMA+10 -n_pix_SMA+10]);
        e122= isequal([i j],[-n_pix_SMA+10 -n_pix_SMA-1+10]);
        e132= isequal([i j],[-n_pix_SMA+10-1 -n_pix_SMA+2+10]);
        e142= isequal([i j],[-n_pix_SMA+10-1 -n_pix_SMA+1+10]);
        e152= isequal([i j],[-n_pix_SMA+10-1 -n_pix_SMA+10]);
        e162= isequal([i j],[-n_pix_SMA+10-1 -n_pix_SMA-1+10]);
        
        if pixels(i,j)==1 && e11==0 && e21==0 && e31==0 && e41==0 && e51==0 && e61==0 && e71==0 && e81==0 && e91==0 ...
             && e101==0 && e111==0 && e121==0 && e131==0 && e141==0 && e151==0 && e161==0 ...
             && e12==0 && e22==0 && e32==0 && e42==0 && e52==0 && e62==0 && e72==0 && e82==0 && e92==0 ...
             && e102==0 && e112==0 && e122==0 && e132==0 && e142==0 && e152==0 && e162==0
            
            ii = ii+1;
            Xblock = [x(j,i)+(unitCellSize-a)/2 x(j,i+1)-(unitCellSize-a)/2];
            Yblock = [y(j,i)+(unitCellSize-b)/2 y(j+1,i)-(unitCellSize-b)/2];
            name = ['Brick',num2str(ii)];
            Cstbrick(mws, name, 'component1', 'Copper (annealed)', Xblock, Yblock, [subHeight subHeight+th_copper]);
            name1=['component1:Brick',num2str(ii)];
            
            %ii = ii+1;
            %Xblock = [x(j,i)+(unitCellSize-a)/2+(b-b1)/2 x(j,i+1)-(unitCellSize-a)/2-(b-b1)/2];
            %Yblock = [y(j,i)+(unitCellSize-b)/2 y(j+1,i)-(unitCellSize-b)/2];
            %name = ['Brick',num2str(ii)];
            %Cstbrick(mws, name, 'component1', 'Copper (annealed)', Xblock, Yblock, [subHeight subHeight+th_copper]);
            %name2=['component1:Brick',num2str(ii)];
            
            component1 = 'component1:Patch_1';
            component2 = name1;
            CstSubtract(mws,component1,component2)
            %component1 = 'component1:Patch_1';
            %component2 = name2;
            %CstSubtract(mws,component1,component2)
            

            %CstAdd('component1:Patch1',name3);

            %a=x(j,i+1)-unitCellSize/(2*nPix)-xlumped/2;
            %b=x(j,i+1)-unitCellSize/(2*nPix)+xlumped/2;
            %CST.addDiscretePort([a b],[y(j+1,i)-unitCellSize/(2*nPix) y(j+1,i)-unitCellSize/(2*nPix)],[subHeight subHeight],0.1,50);  
            %name = ['Inductor',num2str(m)];
            %CST.addLumpedElement(0,Ls,0,[x(j,i+1)-unitCellSize/(2*nPix)-xlumped/2 x(j,i+1)-unitCellSize/(2*nPix)],[y(j+1,i)-unitCellSize/(2*nPix) y(j+1,i)-unitCellSize/(2*nPix)],[subHeight subHeight],name);
            %name = ['RC',num2str(m)];
            %CST.addLumpedElement(Rrv,0,Crv,[x(j,i+1)-unitCellSize/(2*nPix) x(j,i+1)-unitCellSize/(2*nPix)+xlumped/2],[y(j+1,i)-unitCellSize/(2*nPix) y(j+1,i)-unitCellSize/(2*nPix)],[subHeight subHeight],name);
        end
    end
end

Name_Sub='component1:Patch_1';
center = [substrateSize/2 substrateSize/2 0];
move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
CstTranslate(mws,Name_Sub,center,move,'False',1);

%% Create via fences
ra_pin_via = lambda0/20;
t=0;
i = 1;
for j = 1:(2*nPix-1)
        t=t+1;
        material6 = 'Copper (annealed)';
        ComponentList = 'component1';
        name6 = ['Via_2',num2str(t)];
        OuterRadius = ra_pin_via;
        InnerRadius = 0;
        Xcenter = i*unitCellSize/2;
        Ycenter = j*unitCellSize/2;
        Zrange = [0 subHeight];
        Cstcylinder(mws, name6, ComponentList, material6, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange);
        Name_Sub=['component1:Via_2',num2str(t)];
        center = [substrateSize/2 substrateSize/2 0];
        move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
        CstTranslate(mws,Name_Sub,center,move,'False',1);
end

i = nPix;
for j = 1:(2*nPix-1)
        t=t+1;
        material6 = 'Copper (annealed)';
        ComponentList = 'component1';
        name6 = ['Via_2',num2str(t)];
        OuterRadius = ra_pin_via;
        InnerRadius = 0;
        Xcenter = i*unitCellSize-unitCellSize/2;
        Ycenter = j*unitCellSize/2;
        Zrange = [0 subHeight];
        Cstcylinder(mws, name6, ComponentList, material6, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange);
        Name_Sub=['component1:Via_2',num2str(t)];
        center = [substrateSize/2 substrateSize/2 0];
        move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
        CstTranslate(mws,Name_Sub,center,move,'False',1);
end

j = 1;
for i = 1:(2*nPix-1)
        t=t+1;
        material6 = 'Copper (annealed)';
        ComponentList = 'component1';
        name6 = ['Via_2',num2str(t)];
        OuterRadius = ra_pin_via;
        InnerRadius = 0;
        Xcenter = i*unitCellSize/2;
        Ycenter = j*unitCellSize/2;
        Zrange = [0 subHeight];
        Cstcylinder(mws, name6, ComponentList, material6, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange);
        Name_Sub=['component1:Via_2',num2str(t)];
        center = [substrateSize/2 substrateSize/2 0];
        move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
        CstTranslate(mws,Name_Sub,center,move,'False',1);
end

j = nPix;
for i = 1:(2*nPix-1)
        t=t+1;
        material6 = 'Copper (annealed)';
        ComponentList = 'component1';
        name6 = ['Via_2',num2str(t)];
        OuterRadius = ra_pin_via;
        InnerRadius = 0;
        Xcenter = i*unitCellSize/2;
        Ycenter = j*unitCellSize-unitCellSize/2;
        Zrange = [0 subHeight];
        Cstcylinder(mws, name6, ComponentList, material6, 'Z', OuterRadius, InnerRadius, Xcenter, Ycenter, Zrange);
        Name_Sub=['component1:Via_2',num2str(t)];
        center = [substrateSize/2 substrateSize/2 0];
        move = [-substrateSize/2+x_sw_aperture_1,-substrateSize/2+y_sw_aperture_1,0];
        CstTranslate(mws,Name_Sub,center,move,'False',1);
end

%% Define array of (diodes) lumped elemnets - random ON and OFF
m = 0;
v = 0;
%Polar = 1; % polar =1 (Horizontal elements is active)  and polar = 0 (Vertical elements is active)
name =[name_folder,'\diode_on_off_save_random_',num2str(g),num2str(k),'.mat'];
load(name,'diode_on_off_save');
for i = 2:nPix-1
    for j = 2:nPix-1
        %l=randi([0,1]);
        if pixels(i,j)==1
            v=v+1;
            %diode_on_off_save{g,k}(v,1)=l;
            l=diode_on_off_save{g,k}(v,1);
        end
        
        e11= isequal([i j],[10+2 n_pix_SMA+2+10]);
        e21= isequal([i j],[10+2 n_pix_SMA+1+10]);
        e31= isequal([i j],[10+2 n_pix_SMA+10]);
        e41= isequal([i j],[10+2 n_pix_SMA-1+10]);
        e51= isequal([i j],[10+1 n_pix_SMA+2+10]);
        e61= isequal([i j],[10+1 n_pix_SMA+1+10]);
        e71= isequal([i j],[10+1 n_pix_SMA+10]);
        e81= isequal([i j],[10+1 n_pix_SMA-1+10]);
        e91= isequal([i j],[10 n_pix_SMA+2+10]);
        e101= isequal([i j],[10 n_pix_SMA+1+10]);
        e111= isequal([i j],[10 n_pix_SMA+10]);
        e121= isequal([i j],[10 n_pix_SMA-1+10]);
        e131= isequal([i j],[10-1 n_pix_SMA+2+10]);
        e141= isequal([i j],[10-1 n_pix_SMA+1+10]);
        e151= isequal([i j],[10-1 n_pix_SMA+10]);
        e161= isequal([i j],[10-1 n_pix_SMA-1+10]);
        
        e12= isequal([i j],[-n_pix_SMA+10+2 -n_pix_SMA+2+10]);
        e22= isequal([i j],[-n_pix_SMA+10+2 -n_pix_SMA+1+10]);
        e32= isequal([i j],[-n_pix_SMA+10+2 -n_pix_SMA+10]);
        e42= isequal([i j],[-n_pix_SMA+10+2 -n_pix_SMA-1+10]);
        e52= isequal([i j],[-n_pix_SMA+10+1 -n_pix_SMA+2+10]);
        e62= isequal([i j],[-n_pix_SMA+10+1 -n_pix_SMA+1+10]);
        e72= isequal([i j],[-n_pix_SMA+10+1 -n_pix_SMA+10]);
        e82= isequal([i j],[-n_pix_SMA+10+1 -n_pix_SMA-1+10]);
        e92= isequal([i j],[-n_pix_SMA+10 -n_pix_SMA+2+10]);
        e102= isequal([i j],[-n_pix_SMA+10 -n_pix_SMA+1+10]);
        e112= isequal([i j],[-n_pix_SMA+10 -n_pix_SMA+10]);
        e122= isequal([i j],[-n_pix_SMA+10 -n_pix_SMA-1+10]);
        e132= isequal([i j],[-n_pix_SMA+10-1 -n_pix_SMA+2+10]);
        e142= isequal([i j],[-n_pix_SMA+10-1 -n_pix_SMA+1+10]);
        e152= isequal([i j],[-n_pix_SMA+10-1 -n_pix_SMA+10]);
        e162= isequal([i j],[-n_pix_SMA+10-1 -n_pix_SMA-1+10]);
        
        if pixels(i,j)==1 && l==1 && e11==0 && e21==0 && e31==0 && e41==0 && e51==0 && e61==0 && e71==0 && e81==0 && e91==0 ...
             && e101==0 && e111==0 && e121==0 && e131==0 && e141==0 && e151==0 && e161==0 ...
             && e12==0 && e22==0 && e32==0 && e42==0 && e52==0 && e62==0 && e72==0 && e82==0 && e92==0 ...
             && e102==0 && e112==0 && e122==0 && e132==0 && e142==0 && e152==0 && e162==0
        %l=1;
        %Revesre bias of Horizontal elements is active
            m=m+1;  
    
            material = 'Copper (annealed)';
            ComponentList = 'component1';
            name = ['Ring_Add_vertical_2',num2str(m)];
            OuterRadius = 0.001;
            InnerRadius = 0;
            Xcenter = x(j,i)+unitCellSize/2;
            Zcenter = subHeight+th_copper;
            %Yrange = [y(j+1,i)-(unitCellSize-b)/2-s1/2 y(j+1,i)-(unitCellSize-b)/2-s1/2];
            Yrange = [y(j+1,i)-(unitCellSize-b)/2-b/2 y(j+1,i)-(unitCellSize-b)/2-b/2];
            Cstcylinder(mws, name, ComponentList, material, 'Y', OuterRadius, InnerRadius, Xcenter, Zcenter, Yrange);
            Name_Sub=['component1:Ring_Add_vertical_2',num2str(m)];
            center = [substrateSize/2 substrateSize/2 0];
            move = [-substrateSize/2+x_sw_aperture_1 -substrateSize/2+y_sw_aperture_1 0];
            CstTranslate(mws,Name_Sub,center,move,'False',1);

            name = ['Inductorvertical_2',num2str(m)];
            SetP1 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            %SetP2 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-s1/2-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            SetP2 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-b/2-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            CstLumpedElement(mws,name,0,Ls,0,SetP1,SetP2,'RLCSerial');
            name = ['RCvertical_2',num2str(m)];
            SetP1 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-b/2-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            SetP2 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-b-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            %CstLumpedElement(mws,name,Rf,0,0,SetP1,SetP2,'RLCParallel');
            CstLumpedElement(mws,name,Rrv,0,Crv,SetP1,SetP2,'RLCParallel');
        end
        
        % Forward bias of Horizontal elements is active
        if pixels(i,j)==1 && l==0 && e11==0 && e21==0 && e31==0 && e41==0 && e51==0 && e61==0 && e71==0 && e81==0 && e91==0 ...
             && e101==0 && e111==0 && e121==0 && e131==0 && e141==0 && e151==0 && e161==0 ...
             && e12==0 && e22==0 && e32==0 && e42==0 && e52==0 && e62==0 && e72==0 && e82==0 && e92==0 ...
             && e102==0 && e112==0 && e122==0 && e132==0 && e142==0 && e152==0 && e162==0
         
            m=m+1;
            material = 'Copper (annealed)';
            ComponentList = 'component1';
            name = ['Ring_Add_vertical_2',num2str(m)];
            OuterRadius = 0.001;
            InnerRadius = 0;
            Xcenter = x(j,i)+unitCellSize/2;
            Zcenter = subHeight+th_copper;
            %Yrange = [y(j+1,i)-(unitCellSize-b)/2-s1/2 y(j+1,i)-(unitCellSize-b)/2-s1/2];
            Yrange = [y(j+1,i)-(unitCellSize-b)/2-b/2 y(j+1,i)-(unitCellSize-b)/2-b/2];
            Cstcylinder(mws, name, ComponentList, material, 'Y', OuterRadius, InnerRadius, Xcenter, Zcenter, Yrange);
            Name_Sub=['component1:Ring_Add_vertical_2',num2str(m)];
            center = [substrateSize/2 substrateSize/2 0];
            move = [-substrateSize/2+x_sw_aperture_1 -substrateSize/2+y_sw_aperture_1 0];
            CstTranslate(mws,Name_Sub,center,move,'False',1);
            
            name = ['Inductorvertical_2',num2str(m)];
            SetP1 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            %SetP2 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-s1/2-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            SetP2 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-b/2-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            CstLumpedElement(mws,name,0,Ls,0,SetP1,SetP2,'RLCSerial');
            name = ['RCvertical_2',num2str(m)];
            SetP1 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-b/2-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            SetP2 = [x(j,i)+unitCellSize/2-substrateSize/2+x_sw_aperture_1 y(j+1,i)-(unitCellSize-b)/2-b-substrateSize/2+y_sw_aperture_1 subHeight+th_copper];
            CstLumpedElement(mws,name,Rf,0,0,SetP1,SetP2,'RLCParallel');
            %CstLumpedElement(mws,name,Rrv,0,Crv,SetP1,SetP2,'RLCParallel');
        end
    end
end

name =[name_folder,'\diode_on_off_save_random_',num2str(g),num2str(k),'.mat'];
save(name,'diode_on_off_save');

CstTDMMeshSettings_1(mws,15,15);


CstDefineFrequencyRange(mws,20,22)

for monitorindex = 20.00:0.04:22.00

CstDefineEfieldNearMonitor(mws,strcat('e-field', num2str(monitorindex)), monitorindex,subHeight+th_copper+dNFS)
%CstDefineHfieldMonitor(mws,strcat('h-field', num2str(monitorindex)), monitorindex)
%CstDefineFarfieldMonitor(mws,strcat('Farfield',num2str(monitorindex)), monitorindex)
end
%Saves the project
%CstSaveProject(mws)
name = [name_folder,'\DMA_BigArray_OneAperture_NFS_Port12_',num2str(g),num2str(k),'.cst'];
CstSaveAsProject(mws,name) 
CstDefineTimedomainSolver(mws,-40,101)
%CstDefineTimedomainSolver_GPU(mws,-40,101)
%CstDefineTimedomainSolver_DCSolveServer(mws,-40,101)

%Export S-parameters
name_RI = [name_folder,'\Sparameter_RI_Mask',num2str(g),num2str(k)];
exportpath = name_RI; %NameofyourFile should be the same with the name of the file of line 185 bellow
format = 'RI';
CstExportTouchstone(mws,exportpath,format);

%Export nearfield
X=6.25;
Y=6.25;
Z=6.25;
for monitorindex = 20.00:0.04:22.00
name = [name_folder,'\Nearfield_NFS_P1_center_Mask_',num2str(g),num2str(k),'_f',num2str(monitorindex),'.txt'];
exportpath = name;
CstExportNearfield_1(mws,exportpath,monitorindex,X,Y,Z)
end

for monitorindex = 20.00:0.04:22.00
name = [name_folder,'\Nearfield_NFS_P2_center_Mask_',num2str(g),num2str(k),'_f',num2str(monitorindex),'.txt'];
exportpath = name;
CstExportNearfield_2(mws,exportpath,monitorindex,X,Y,Z)
end

%CstSaveProject(mws)
%CstQuitProject(mws)

end % Finish of random ON/OFF (random diodes ON/OFF in array)

name =[name_folder,'\pixels_save_',num2str(g),'.mat'];

save(name,'pixels_save');
end

